import './public-path'
import * as Vue from 'vue'
import { createRouter, createWebHistory, RouterHistory, Router } from 'vue-router'
import App from './App.vue'
import routes from './router'
import store from './store'

declare global {
    interface Window {
        __POWERED_BY_QIANKUN__: string | boolean
    }
}

let router: Router | undefined = undefined
let instance: Vue.App<Element> | undefined = undefined
let history: RouterHistory | undefined = undefined

function render(props?: { container: HTMLElement | null | undefined }) {
    const { container } = props || {}

    history = createWebHistory(window.__POWERED_BY_QIANKUN__ ? '/profile' : '/')
    router = createRouter({
        history,
        routes
    })

    instance = Vue.createApp(App)
    instance.use(router)
    instance.use(store)
    instance.mount(container ? (container.querySelector('#app') as HTMLElement) : '#app')
}

// 独立运行时
if (!window.__POWERED_BY_QIANKUN__) {
    render()
}

export async function bootstrap() {
    console.log('[vue] vue app bootstraped')
}

export async function mount(props: any) {
    console.log('[vue] props from main framework', props)
    render(props)
}

export async function unmount() {
    instance?.unmount()
    instance && instance._container && (instance._container.innerHTML = '')
    instance = undefined
    router = undefined
    history?.destroy()
    history = undefined
}

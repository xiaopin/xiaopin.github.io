<template>
    <div>
        <div class="main-app">
            <span @click="open('/home')">Home</span>
            <span>|</span>
            <span @click="open('/profile')">Profile</span>
        </div>
        <div id="subapp-container"></div>
    </div>
</template>

<script setup lang="ts">
import { registerMicroApps, start, setDefaultMountApp } from 'qiankun'

// 注册微应用
registerMicroApps([
    {
        name: 'Home Micro App',
        entry: '//localhost:9001',
        container: '#subapp-container',
        activeRule: '/home'
    },
    {
        name: 'Profile Micro App',
        entry: '//localhost:9002',
        container: '#subapp-container',
        activeRule: '/profile'
    }
])
// 设置默认挂载的应用
setDefaultMountApp('/home')
// 启动应用
start()

const open = (path: string): void => {
    window.history.replaceState(null, path, path)
}
</script>
